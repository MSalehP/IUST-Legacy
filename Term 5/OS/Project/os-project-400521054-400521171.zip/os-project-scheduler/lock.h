struct lock {
    uint locked; // 0 if unlocked, 1 if locked
};