# Generated from C:/PHD/Subjects/Compiler_4022/First_excercise/Simple-Calculator/grammar/ArithmeticExpression.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,12,75,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,25,8,1,1,2,1,2,1,2,
        1,2,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,42,8,4,10,4,
        12,4,45,9,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,5,5,56,8,5,10,5,
        12,5,59,9,5,1,6,3,6,62,8,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,3,6,71,8,
        6,1,7,1,7,1,7,0,2,8,10,8,0,2,4,6,8,10,12,14,0,1,1,0,2,3,75,0,16,
        1,0,0,0,2,24,1,0,0,0,4,26,1,0,0,0,6,30,1,0,0,0,8,32,1,0,0,0,10,46,
        1,0,0,0,12,70,1,0,0,0,14,72,1,0,0,0,16,17,3,2,1,0,17,18,5,0,0,1,
        18,1,1,0,0,0,19,20,3,4,2,0,20,21,5,11,0,0,21,22,3,2,1,0,22,25,1,
        0,0,0,23,25,3,4,2,0,24,19,1,0,0,0,24,23,1,0,0,0,25,3,1,0,0,0,26,
        27,3,6,3,0,27,28,5,1,0,0,28,29,3,8,4,0,29,5,1,0,0,0,30,31,5,12,0,
        0,31,7,1,0,0,0,32,33,6,4,-1,0,33,34,3,10,5,0,34,43,1,0,0,0,35,36,
        10,3,0,0,36,37,5,2,0,0,37,42,3,8,4,4,38,39,10,2,0,0,39,40,5,3,0,
        0,40,42,3,8,4,3,41,35,1,0,0,0,41,38,1,0,0,0,42,45,1,0,0,0,43,41,
        1,0,0,0,43,44,1,0,0,0,44,9,1,0,0,0,45,43,1,0,0,0,46,47,6,5,-1,0,
        47,48,3,12,6,0,48,57,1,0,0,0,49,50,10,3,0,0,50,51,5,4,0,0,51,56,
        3,10,5,4,52,53,10,2,0,0,53,54,5,5,0,0,54,56,3,10,5,3,55,49,1,0,0,
        0,55,52,1,0,0,0,56,59,1,0,0,0,57,55,1,0,0,0,57,58,1,0,0,0,58,11,
        1,0,0,0,59,57,1,0,0,0,60,62,3,14,7,0,61,60,1,0,0,0,61,62,1,0,0,0,
        62,63,1,0,0,0,63,71,5,8,0,0,64,65,5,6,0,0,65,66,3,8,4,0,66,67,5,
        7,0,0,67,71,1,0,0,0,68,71,5,12,0,0,69,71,5,9,0,0,70,61,1,0,0,0,70,
        64,1,0,0,0,70,68,1,0,0,0,70,69,1,0,0,0,71,13,1,0,0,0,72,73,7,0,0,
        0,73,15,1,0,0,0,7,24,41,43,55,57,61,70
    ]

class ArithmeticExpressionParser ( Parser ):

    grammarFileName = "ArithmeticExpression.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'+'", "'-'", "'*'", "'/'", "'('", 
                     "')'", "<INVALID>", "<INVALID>", "<INVALID>", "'\\n'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "ADD", "SUB", "MUL", "DIV", 
                      "LPAREN", "RPAREN", "NUMERICALVALUE", "STRING", "WS", 
                      "NEWLINE", "ID" ]

    RULE_start = 0
    RULE_assigns = 1
    RULE_assign = 2
    RULE_id = 3
    RULE_expr = 4
    RULE_term = 5
    RULE_factor = 6
    RULE_sign = 7

    ruleNames =  [ "start", "assigns", "assign", "id", "expr", "term", "factor", 
                   "sign" ]

    EOF = Token.EOF
    T__0=1
    ADD=2
    SUB=3
    MUL=4
    DIV=5
    LPAREN=6
    RPAREN=7
    NUMERICALVALUE=8
    STRING=9
    WS=10
    NEWLINE=11
    ID=12

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assigns(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.AssignsContext,0)


        def EOF(self):
            return self.getToken(ArithmeticExpressionParser.EOF, 0)

        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart" ):
                listener.enterStart(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart" ):
                listener.exitStart(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart" ):
                return visitor.visitStart(self)
            else:
                return visitor.visitChildren(self)




    def start(self):

        localctx = ArithmeticExpressionParser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 16
            self.assigns()
            self.state = 17
            self.match(ArithmeticExpressionParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assign(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.AssignContext,0)


        def NEWLINE(self):
            return self.getToken(ArithmeticExpressionParser.NEWLINE, 0)

        def assigns(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.AssignsContext,0)


        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_assigns

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssigns" ):
                listener.enterAssigns(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssigns" ):
                listener.exitAssigns(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssigns" ):
                return visitor.visitAssigns(self)
            else:
                return visitor.visitChildren(self)




    def assigns(self):

        localctx = ArithmeticExpressionParser.AssignsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_assigns)
        try:
            self.state = 24
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 19
                self.assign()
                self.state = 20
                self.match(ArithmeticExpressionParser.NEWLINE)
                self.state = 21
                self.assigns()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 23
                self.assign()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.IdContext,0)


        def expr(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.ExprContext,0)


        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_assign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign" ):
                listener.enterAssign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign" ):
                listener.exitAssign(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssign" ):
                return visitor.visitAssign(self)
            else:
                return visitor.visitChildren(self)




    def assign(self):

        localctx = ArithmeticExpressionParser.AssignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_assign)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 26
            self.id_()
            self.state = 27
            self.match(ArithmeticExpressionParser.T__0)
            self.state = 28
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ArithmeticExpressionParser.ID, 0)

        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterId" ):
                listener.enterId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitId" ):
                listener.exitId(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitId" ):
                return visitor.visitId(self)
            else:
                return visitor.visitChildren(self)




    def id_(self):

        localctx = ArithmeticExpressionParser.IdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 30
            self.match(ArithmeticExpressionParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.rule_type = str()

        def term(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.TermContext,0)


        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ArithmeticExpressionParser.ExprContext)
            else:
                return self.getTypedRuleContext(ArithmeticExpressionParser.ExprContext,i)


        def ADD(self):
            return self.getToken(ArithmeticExpressionParser.ADD, 0)

        def SUB(self):
            return self.getToken(ArithmeticExpressionParser.SUB, 0)

        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ArithmeticExpressionParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 8
        self.enterRecursionRule(localctx, 8, self.RULE_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33
            self.term(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 43
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 41
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                    if la_ == 1:
                        localctx = ArithmeticExpressionParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 35
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 36
                        self.match(ArithmeticExpressionParser.ADD)
                        self.state = 37
                        self.expr(4)
                        pass

                    elif la_ == 2:
                        localctx = ArithmeticExpressionParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 38
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 39
                        self.match(ArithmeticExpressionParser.SUB)
                        self.state = 40
                        self.expr(3)
                        pass

             
                self.state = 45
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.rule_type = str()

        def factor(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.FactorContext,0)


        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ArithmeticExpressionParser.TermContext)
            else:
                return self.getTypedRuleContext(ArithmeticExpressionParser.TermContext,i)


        def MUL(self):
            return self.getToken(ArithmeticExpressionParser.MUL, 0)

        def DIV(self):
            return self.getToken(ArithmeticExpressionParser.DIV, 0)

        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)



    def term(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ArithmeticExpressionParser.TermContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 10
        self.enterRecursionRule(localctx, 10, self.RULE_term, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 47
            self.factor()
            self._ctx.stop = self._input.LT(-1)
            self.state = 57
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 55
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                    if la_ == 1:
                        localctx = ArithmeticExpressionParser.TermContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 49
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 50
                        self.match(ArithmeticExpressionParser.MUL)
                        self.state = 51
                        self.term(4)
                        pass

                    elif la_ == 2:
                        localctx = ArithmeticExpressionParser.TermContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 52
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 53
                        self.match(ArithmeticExpressionParser.DIV)
                        self.state = 54
                        self.term(3)
                        pass

             
                self.state = 59
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.rule_type = str()


        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_factor

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)
            self.rule_type = ctx.rule_type



    class Factor_is_stringContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ArithmeticExpressionParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(ArithmeticExpressionParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor_is_string" ):
                listener.enterFactor_is_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor_is_string" ):
                listener.exitFactor_is_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor_is_string" ):
                return visitor.visitFactor_is_string(self)
            else:
                return visitor.visitChildren(self)


    class Factor_is_expressionContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ArithmeticExpressionParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(ArithmeticExpressionParser.LPAREN, 0)
        def expr(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.ExprContext,0)

        def RPAREN(self):
            return self.getToken(ArithmeticExpressionParser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor_is_expression" ):
                listener.enterFactor_is_expression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor_is_expression" ):
                listener.exitFactor_is_expression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor_is_expression" ):
                return visitor.visitFactor_is_expression(self)
            else:
                return visitor.visitChildren(self)


    class Factor_is_idContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ArithmeticExpressionParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(ArithmeticExpressionParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor_is_id" ):
                listener.enterFactor_is_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor_is_id" ):
                listener.exitFactor_is_id(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor_is_id" ):
                return visitor.visitFactor_is_id(self)
            else:
                return visitor.visitChildren(self)


    class Factor_is_numericContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ArithmeticExpressionParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMERICALVALUE(self):
            return self.getToken(ArithmeticExpressionParser.NUMERICALVALUE, 0)
        def sign(self):
            return self.getTypedRuleContext(ArithmeticExpressionParser.SignContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor_is_numeric" ):
                listener.enterFactor_is_numeric(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor_is_numeric" ):
                listener.exitFactor_is_numeric(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor_is_numeric" ):
                return visitor.visitFactor_is_numeric(self)
            else:
                return visitor.visitChildren(self)



    def factor(self):

        localctx = ArithmeticExpressionParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_factor)
        self._la = 0 # Token type
        try:
            self.state = 70
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2, 3, 8]:
                localctx = ArithmeticExpressionParser.Factor_is_numericContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 61
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==2 or _la==3:
                    self.state = 60
                    self.sign()


                self.state = 63
                self.match(ArithmeticExpressionParser.NUMERICALVALUE)
                pass
            elif token in [6]:
                localctx = ArithmeticExpressionParser.Factor_is_expressionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 64
                self.match(ArithmeticExpressionParser.LPAREN)
                self.state = 65
                self.expr(0)
                self.state = 66
                self.match(ArithmeticExpressionParser.RPAREN)
                pass
            elif token in [12]:
                localctx = ArithmeticExpressionParser.Factor_is_idContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 68
                self.match(ArithmeticExpressionParser.ID)
                pass
            elif token in [9]:
                localctx = ArithmeticExpressionParser.Factor_is_stringContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 69
                self.match(ArithmeticExpressionParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ADD(self):
            return self.getToken(ArithmeticExpressionParser.ADD, 0)

        def SUB(self):
            return self.getToken(ArithmeticExpressionParser.SUB, 0)

        def getRuleIndex(self):
            return ArithmeticExpressionParser.RULE_sign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSign" ):
                listener.enterSign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSign" ):
                listener.exitSign(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSign" ):
                return visitor.visitSign(self)
            else:
                return visitor.visitChildren(self)




    def sign(self):

        localctx = ArithmeticExpressionParser.SignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            _la = self._input.LA(1)
            if not(_la==2 or _la==3):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[4] = self.expr_sempred
        self._predicates[5] = self.term_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         

    def term_sempred(self, localctx:TermContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         




