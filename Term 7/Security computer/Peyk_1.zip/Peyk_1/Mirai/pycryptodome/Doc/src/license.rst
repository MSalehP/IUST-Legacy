License
-------

.. include:: ../../LICENSE.rst

