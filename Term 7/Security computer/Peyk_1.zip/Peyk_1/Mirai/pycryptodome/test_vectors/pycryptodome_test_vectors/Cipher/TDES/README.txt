Files downloaded from the NIST website on November 9, 2015 as:

* http://csrc.nist.gov/groups/STM/cavp/documents/des/KAT_TDES.zip
* http://csrc.nist.gov/groups/STM/cavp/documents/des/tdesmmt.zip
